```
Interval empty among frame-robust Frame C Cascade-led zones: (0.226, 0.300)

2011: 7 of 213 Frame C Cascade-led zones inside the interval (0 frame-robust)
2021: 9 of 195 Frame C Cascade-led zones inside the interval (0 frame-robust)

London-wide shares: super 9.6%, mainstream 4.0%, marginal 10.3%, any 21.1%

2011 (zones; % containing super / mainstream / any gentrification):
                                zones                    super_share                    mainstream_share                     any_share                   
cut_label                  lower edge adopted upper edge  lower edge adopted upper edge       lower edge adopted upper edge lower edge adopted upper edge
profile                                                                                                                                                  
inflow-driven                      56      56         56        16.1    16.1       16.1              8.9     8.9        8.9       32.1    32.1       32.1
frame-sensitive inflow             60      57         53        11.7    10.5       11.3              6.7     7.0        7.5       21.7    21.1       22.6
outflow: internal-majority         80      81         83        22.5    22.2       21.7              3.8     3.7        3.6       28.7    28.4       27.7
outflow: external-majority         17      19         21        17.6    21.1       19.0              0.0     0.0        0.0       23.5    26.3       23.8

2021 (zones; % containing super / mainstream / any gentrification):
                                zones                    super_share                    mainstream_share                     any_share                   
cut_label                  lower edge adopted upper edge  lower edge adopted upper edge       lower edge adopted upper edge lower edge adopted upper edge
profile                                                                                                                                                  
inflow-driven                      13      13         13        15.4    15.4       15.4              0.0     0.0        0.0       30.8    30.8       30.8
frame-sensitive inflow             17      14          8        11.8     7.1       12.5              0.0     0.0        0.0       17.6    14.3       25.0
outflow: internal-majority         90      90         90        32.2    32.2       32.2              2.2     2.2        2.2       36.7    36.7       36.7
outflow: external-majority         75      78         84         5.3     6.4        6.0              0.0     0.0        0.0        8.0     9.0        8.3

```
