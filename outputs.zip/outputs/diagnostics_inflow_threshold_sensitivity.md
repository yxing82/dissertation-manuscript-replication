```
Interval empty among frame-robust Frame C Cascade-led zones: (0.220, 0.299)

2011: 6 of 205 Frame C Cascade-led zones inside the interval (0 frame-robust)
2021: 8 of 193 Frame C Cascade-led zones inside the interval (0 frame-robust)

London-wide shares: super 9.6%, mainstream 4.0%, marginal 10.3%, any 21.1%

2011 (zones; % containing super / mainstream / any gentrification):
                                zones                    super_share                    mainstream_share                     any_share                   
cut_label                  lower edge adopted upper edge  lower edge adopted upper edge       lower edge adopted upper edge lower edge adopted upper edge
profile                                                                                                                                                  
inflow-driven                      56      56         56        19.6    19.6       19.6             10.7    10.7       10.7       37.5    37.5       37.5
frame-sensitive inflow             54      51         48         7.4     5.9        6.2              5.6     5.9        6.2       16.7    15.7       16.7
outflow: internal-majority         78      79         80        23.1    22.8       22.5              3.8     3.8        3.8       29.5    29.1       28.7
outflow: external-majority         17      19         21        17.6    21.1       19.0              0.0     0.0        0.0       23.5    26.3       23.8

2021 (zones; % containing super / mainstream / any gentrification):
                                zones                    super_share                    mainstream_share                     any_share                   
cut_label                  lower edge adopted upper edge  lower edge adopted upper edge       lower edge adopted upper edge lower edge adopted upper edge
profile                                                                                                                                                  
inflow-driven                      10      10         10        10.0    10.0       10.0              0.0     0.0        0.0       30.0    30.0       30.0
frame-sensitive inflow             18      16         10        11.1     6.2       10.0              0.0     0.0        0.0       11.1     6.2       10.0
outflow: internal-majority         89      89         89        31.5    31.5       31.5              2.2     2.2        2.2       36.0    36.0       36.0
outflow: external-majority         76      78         84         5.3     6.4        6.0              0.0     0.0        0.0        7.9     9.0        8.3

```
