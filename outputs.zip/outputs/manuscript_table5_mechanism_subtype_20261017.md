| Mechanism profile | Window | Zones | Super | Mainstream | Marginal | Any gentrification |
| --- | --- | --- | --- | --- | --- | --- |
| Inflow-driven, frame-robust | 2011 | 56 | 11 (19.6%, +10.1) | 6 (10.7%, +6.7) | 6 (10.7%, +0.4) | 21 (37.5%, +16.4) |
| Inflow-driven, frame-robust | 2021 | 10 | 1 (10.0%, +0.4) | 0 (0.0%, −4.0) | 2 (20.0%, +9.7) | 3 (30.0%, +8.9) |
| Frame-sensitive inflow | 2011 | 51 | 3 (5.9%, −3.7) | 3 (5.9%, +1.9) | 2 (3.9%, −6.4) | 8 (15.7%, −5.4) |
| Frame-sensitive inflow | 2021 | 16 | 1 (6.2%, −3.3) | 0 (0.0%, −4.0) | 0 (0.0%, −10.3) | 1 (6.2%, −14.8) |
| Outflow-internal-majority | 2011 | 79 | 18 (22.8%, +13.2) | 3 (3.8%, −0.2) | 6 (7.6%, −2.7) | 23 (29.1%, +8.0) |
| Outflow-internal-majority | 2021 | 89 | 28 (31.5%, +21.9) | 2 (2.2%, −1.7) | 7 (7.9%, −2.4) | 32 (36.0%, +14.9) |
| Outflow-external-majority | 2011 | 19 | 4 (21.1%, +11.5) | 0 (0.0%, −4.0) | 1 (5.3%, −5.0) | 5 (26.3%, +5.2) |
| Outflow-external-majority | 2021 | 78 | 5 (6.4%, −3.2) | 0 (0.0%, −4.0) | 2 (2.6%, −7.7) | 7 (9.0%, −12.1) |
| London-wide | – | 982 | 94 (9.6%) | 39 (4.0%) | 101 (10.3%) | 207 (21.1%) |

Cells: zones containing the category (share of the profile's zones, percentage-point difference from the London-wide share across all 982 zones). Descriptive comparison; no significance tests.
